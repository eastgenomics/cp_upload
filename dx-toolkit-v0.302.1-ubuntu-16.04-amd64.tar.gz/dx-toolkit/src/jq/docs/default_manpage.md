jq(1) -- Command-line JSON processor
====================================

## DESCRIPTION

`jq` can transform JSON in various ways, by selecting, iterating,
reducing and otherwise mangling JSON documents. 

This version of `jq` was built without a manual, so this manpage is a
stub. For full documentation of the `jq` language, see:

    http://stedolan.github.com/jq
    
## BUGS

Presumably. Report them or discuss them at:

    https://github.com/stedolan/jq/issues

## AUTHOR

Stephen Dolan `<mu@netsoc.tcd.ie>`
