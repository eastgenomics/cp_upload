#ifndef JV_FILE_H
#define JV_FILE_H

#include "jv.h"

jv jv_load_file(const char *, int);

#endif
