/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "jq"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "mu@netsoc.tcd.ie"

/* Define to the full name of this package. */
#define PACKAGE_NAME "jq"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "jq 1.3"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "jq"

/* Define to the home page for this package. */
#define PACKAGE_URL "http://stedolan.github.com/jq/"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.3"

/* Version number of package */
#define VERSION "1.3"

/* Define to 1 if `lex' declares `yytext' as a `char *' by default, not a
   `char[]'. */
#define YYTEXT_POINTER 1
