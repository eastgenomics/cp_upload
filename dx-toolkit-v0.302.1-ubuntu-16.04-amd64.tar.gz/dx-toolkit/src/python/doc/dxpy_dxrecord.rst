Records
+++++++

.. automodule:: dxpy.bindings.dxrecord
   :members:
   :undoc-members:
   :show-inheritance:
