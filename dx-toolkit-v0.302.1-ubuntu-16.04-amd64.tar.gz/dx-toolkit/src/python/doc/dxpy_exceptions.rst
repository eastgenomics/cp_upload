:mod:`dxpy.exceptions` Module
-----------------------------

.. automodule:: dxpy.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
