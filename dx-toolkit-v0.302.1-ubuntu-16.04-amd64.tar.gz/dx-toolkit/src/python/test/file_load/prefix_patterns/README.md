Tests that the bash prefix variable works correctly, and respects patterns.
