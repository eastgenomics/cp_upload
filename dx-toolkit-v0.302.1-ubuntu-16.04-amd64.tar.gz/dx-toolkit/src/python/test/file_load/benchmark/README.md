This is a benchmark for parallel vs. sequential performance. It downloads N files, and then uploads those same N files.
