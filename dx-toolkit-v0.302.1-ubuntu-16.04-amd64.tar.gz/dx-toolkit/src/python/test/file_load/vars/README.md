This is a testing app, for the dx-upload/download-all python scripts.
