This test checks that the upload/download utilities work correctly. In
particular, it checks that the parallel/sequential variations are correct.

