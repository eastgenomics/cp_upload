Tests for the bash helpers that support uploading and downloading
files. The directory contains subdirectories that are apps.
