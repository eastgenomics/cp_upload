A test app to check file optional inputs.
