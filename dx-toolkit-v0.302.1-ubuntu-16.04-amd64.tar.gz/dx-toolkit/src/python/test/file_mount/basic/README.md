This is a testing app, for the mount-all-inputs python script.

