Contributed components
======================

The components in this directory are **unsupported**, even though they
are in the official source distribution.

The intent of this space is to provide a centralized place where
somewhat experimental or unsupported ideas can be maintained. You can
use them as a starting point for your own work. If you can make a case
for something in here to be fully supported, it can graduate and be
moved out of this directory and into `/src`.
